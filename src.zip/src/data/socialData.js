


const socialData = {
        id: 'social',
        title: 'Section 3: Social Interaction',
        description: 'Rate your comfort level in these scenarios.',
        questions:[
            // --- SUB-CATEGORY: CROWDS & ENVIRONMENTS ---
                        { id: 's_1', text: 'Being in the center of a crowded dance floor' },
                        { id: 's_2', text: 'Attending large music festivals or concerts' },
                        { id: 's_3', text: 'Quiet, intimate dinners with 1-2 close friends' },
                        { id: 's_4', text: 'Networking events where I know nobody' },
                        { id: 's_5', text: 'Working in a bustling, noisy coffee shop' },
                        { id: 's_6', text: 'Spending Friday night completely alone' },
                        { id: 's_7', text: 'Hosting a large party at my home' },
                        { id: 's_8', text: 'Attending formal weddings or galas' },
                        { id: 's_9', text: 'Being stuck in an elevator with strangers' },
                        { id: 's_10', text: 'Open-plan offices with no privacy' },

                        // --- SUB-CATEGORY: CONVERSATION STYLES ---
                        { id: 's_11', text: 'Engaging in "Small Talk" with cashiers or strangers' },
                        { id: 's_12', text: 'Debating controversial topics (Politics/Religion) publicly' },
                        { id: 's_13', text: 'Listening to others vent without offering solutions' },
                        { id: 's_14', text: 'Being the one who keeps the conversation going' },
                        { id: 's_15', text: 'Comfortable silence with another person' },
                        { id: 's_16', text: 'Using humor or sarcasm to deflect tension' },
                        { id: 's_17', text: 'Complimenting strangers on their appearance' },
                        { id: 's_18', text: 'Talking about deep emotional trauma on a first date' },
                        { id: 's_19', text: 'Gossiping about mutual acquaintances' },
                        { id: 's_20', text: 'Intellectual discussions about abstract theories' },

                        // --- SUB-CATEGORY: COMMUNICATION CHANNELS ---
                        { id: 's_21', text: 'Talking on the phone (Voice calls)' },
                        { id: 's_22', text: 'Video calling (FaceTime/Zoom)' },
                        { id: 's_23', text: 'Texting or instant messaging' },
                        { id: 's_24', text: 'Sending voice notes instead of typing' },
                        { id: 's_25', text: 'Writing handwritten letters' },
                        { id: 's_26', text: 'Public speaking in front of a large audience' },
                        { id: 's_27', text: 'Recording myself on video for social media' },
                        { id: 's_28', text: 'Group chats with many active members' },
                        { id: 's_29', text: 'One-on-one interactions over group hangs' },
                        { id: 's_30', text: 'Replying to messages immediately upon receipt' },

                        // --- SUB-CATEGORY: LEADERSHIP & GROUP ROLE ---
                        { id: 's_31', text: 'Taking charge during a crisis situation' },
                        { id: 's_32', text: 'Organizing group trips or itineraries' },
                        { id: 's_33', text: 'Following instructions without questioning' },
                        { id: 's_34', text: 'Mediating arguments between friends' },
                        { id: 's_35', text: 'Being the center of attention' },
                        { id: 's_36', text: 'Blending into the background (Wallflower)' },
                        { id: 's_37', text: 'Delegating tasks to others' },
                        { id: 's_38', text: 'Mentoring or teaching someone new skills' },
                        { id: 's_39', text: 'Collaborating on group projects' },
                        { id: 's_40', text: 'Working completely independently' },

                        // --- SUB-CATEGORY: SOCIAL ETIQUETTE & BEHAVIOR ---
                        { id: 's_41', text: 'Arriving 15 minutes early to appointments' },
                        { id: 's_42', text: 'Adhering to strict dress codes' },
                        { id: 's_43', text: 'Sharing food nicely (family style)' },
                        { id: 's_44', text: 'Splitting the bill evenly regardless of what was ordered' },
                        { id: 's_45', text: 'Hugging people upon first meeting' },
                        { id: 's_46', text: 'Shaking hands firmly' },
                        { id: 's_47', text: 'Maintaining strong eye contact while talking' },
                        { id: 's_48', text: 'Apologizing even when it might not be my fault' },
                        { id: 's_49', text: 'Remembering names after meeting someone once' },
                        { id: 's_50', text: 'Giving expensive gifts' },

                        // --- SUB-CATEGORY: RELATIONSHIP DYNAMICS ---
                        { id: 's_51', text: 'Public Displays of Affection (PDA)' },
                        { id: 's_52', text: 'Spending 24/7 with a partner' },
                        { id: 's_53', text: 'Having separate hobbies from my partner' },
                        { id: 's_54', text: 'Jealousy or possessiveness in relationships' },
                        { id: 's_55', text: 'Celebrating "month-a-versaries"' },
                        { id: 's_56', text: 'Maintaining friendships with ex-partners' },
                        { id: 's_57', text: 'asking for help when struggling' },
                        { id: 's_58', text: 'Confronting someone who has upset me' },
                        { id: 's_59', text: 'Cutting toxic people out of my life instantly' },
                        { id: 's_60', text: 'Giving people second chances' },

                        // --- SUB-CATEGORY: SOCIAL ENERGY & BATTERY ---
                        { id: 's_61', text: 'Staying out late (after midnight)' },
                        { id: 's_62', text: 'Waking up early to socialize (Breakfast/Brunch)' },
                        { id: 's_63', text: 'Socializing every single day of the week' },
                        { id: 's_64', text: 'Going "off the grid" (no contact) for days' },
                        { id: 's_65', text: 'Spontaneous, unplanned hangouts' },
                        { id: 's_66', text: 'Having plans cancelled at the last minute (Relief?)' },
                        { id: 's_67', text: 'Traveling with a large group of friends' },
                        { id: 's_68', text: 'Meeting my partner\'s family/parents' },
                        { id: 's_69', text: 'Attending high school reunions' },
                        { id: 's_70', text: 'Participating in team-building exercises' },

                        // --- SUB-CATEGORY: ONLINE SOCIAL BEHAVIOR ---
                        { id: 's_71', text: 'Posting selfies regularly' },
                        { id: 's_72', text: 'Engaging in debates in comment sections' },
                        { id: 's_73', text: 'Keeping my social media profiles private' },
                        { id: 's_74', text: 'Meeting internet friends in real life' },
                        { id: 's_75', text: 'Online dating apps' },
                        { id: 's_76', text: 'Lurking (reading without posting)' },
                        { id: 's_77', text: 'Blocking people liberally' },
                        { id: 's_78', text: 'Curating a perfect aesthetic online' },
                        { id: 's_79', text: 'Sharing memes as a love language' },
                        { id: 's_80', text: 'Deleting social media entirely' },
                        
                        // --- SUB-CATEGORY: MISCELLANEOUS SOCIAL PREFERENCES ---
                        { id: 's_81', text: 'Board game nights' },
                        { id: 's_82', text: 'Karaoke nights' },
                        { id: 's_83', text: 'Escape rooms' },
                        { id: 's_84', text: 'Volunteering in the community' },
                        { id: 's_85', text: 'Babysitting or interacting with children' },
                        { id: 's_86', text: 'Interacting with elderly people' },
                        { id: 's_87', text: 'Asking strangers for directions' },
                        { id: 's_88', text: 'Returning a meal at a restaurant if it\'s wrong' },
                        { id: 's_89', text: 'Tipping generously regardless of service quality' },
                        { id: 's_90', text: 'Being the "Designated Driver" (Staying sober)' }
                    ]
    }

                        export default socialData;