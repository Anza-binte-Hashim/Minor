


const habitsData = {                 
        id: 'habits',
        title: 'Section 4: Daily Habits & Conscientiousness',
        description: 'Does this describe your daily life?',
        questions:[
                    // --- SUB-CATEGORY: PHYSICAL & ATHLETICS ---
                    { id: 'h_1', text: 'Playing high-contact team sports (e.g., Soccer, Basketball, Rugby)' },
                    { id: 'h_2', text: 'Endurance activities (e.g., Long-distance running, Marathons)' },
                    { id: 'h_3', text: 'Weightlifting and bodybuilding' },
                    { id: 'h_4', text: 'Swimming or water sports' },
                    { id: 'h_5', text: 'Yoga or Pilates' },
                    { id: 'h_6', text: 'Martial arts or combat sports (e.g., Boxing, MMA, Jiu-Jitsu)' },
                    { id: 'h_7', text: 'Winter sports (e.g., Skiing, Snowboarding)' },
                    { id: 'h_8', text: 'Racquet sports (e.g., Tennis, Badminton, Squash)' },
                    { id: 'h_9', text: 'Cycling (Road or Mountain biking)' },
                    { id: 'h_10', text: 'Dancing (Social, Salsa, Ballroom, Hip-hop)' },

                    // --- SUB-CATEGORY: OUTDOOR & NATURE ---
                    { id: 'h_11', text: 'Hiking in the mountains' },
                    { id: 'h_12', text: 'Camping in the wilderness' },
                    { id: 'h_13', text: 'Fishing or Hunting' },
                    { id: 'h_14', text: 'Gardening and maintaining plants' },
                    { id: 'h_15', text: 'Bird watching or wildlife photography' },
                    { id: 'h_16', text: 'Rock climbing or bouldering' },
                    { id: 'h_17', text: 'Stargazing / Astronomy' },
                    { id: 'h_18', text: 'Off-roading or 4x4 driving' },
                    { id: 'h_19', text: 'Picnicking in parks' },
                    { id: 'h_20', text: 'Survivalism / Bushcraft skills' },

                    // --- SUB-CATEGORY: GAMING & STRATEGY ---
                    { id: 'h_21', text: 'Playing First-Person Shooter (FPS) video games' },
                    { id: 'h_22', text: 'Playing Massively Multiplayer Online (MMO) games' },
                    { id: 'h_23', text: 'Strategy board games (e.g., Catan, Risk)' },
                    { id: 'h_24', text: 'Tabletop Role-Playing Games (e.g., Dungeons & Dragons)' },
                    { id: 'h_25', text: 'Solving complex logic puzzles (Sudoku, Crosswords)' },
                    { id: 'h_26', text: 'Chess or Go' },
                    { id: 'h_27', text: 'Retro gaming / Arcade games' },
                    { id: 'h_28', text: 'Mobile gaming (Casual)' },
                    { id: 'h_29', text: 'Card games (Poker, Bridge)' },
                    { id: 'h_30', text: 'Following eSports tournaments' },

                    // --- SUB-CATEGORY: CREATIVE ARTS ---
                    { id: 'h_31', text: 'Drawing, sketching, or painting' },
                    { id: 'h_32', text: 'Creative writing (Fiction, Poetry)' },
                    { id: 'h_33', text: 'Playing a musical instrument' },
                    { id: 'h_34', text: 'Digital art or Graphic Design' },
                    { id: 'h_35', text: 'Photography' },
                    { id: 'h_36', text: 'Filmmaking or Video Editing' },
                    { id: 'h_37', text: 'Pottery or sculpting' },
                    { id: 'h_38', text: 'Singing (Choir or Solo)' },
                    { id: 'h_39', text: 'Acting or Theater participation' },
                    { id: 'h_40', text: 'Calligraphy' },

                    // --- SUB-CATEGORY: MAKER & DIY ---
                    { id: 'h_41', text: 'Woodworking or Carpentry' },
                    { id: 'h_42', text: 'Knitting, Crochet, or Sewing' },
                    { id: 'h_43', text: 'Cooking complex meals from scratch' },
                    { id: 'h_44', text: 'Baking and pastry making' },
                    { id: 'h_45', text: 'Home improvement / DIY repairs' },
                    { id: 'h_46', text: 'Car restoration or mechanics' },
                    { id: 'h_47', text: 'Electronics / Robotics (Arduino, Raspberry Pi)' },
                    { id: 'h_48', text: 'Model building (Planes, Trains, Miniatures)' },
                    { id: 'h_49', text: 'Brewing coffee (Barista skills)' },
                    { id: 'h_50', text: 'Interior Decorating' },

                    // --- SUB-CATEGORY: INTELLECTUAL & PASSIVE ---
                    { id: 'h_51', text: 'Reading fiction novels' },
                    { id: 'h_52', text: 'Reading non-fiction / Biographies' },
                    { id: 'h_53', text: 'Listening to Audiobooks' },
                    { id: 'h_54', text: 'Listening to Podcasts (Educational/Interview)' },
                    { id: 'h_55', text: 'Watching Documentaries' },
                    { id: 'h_56', text: 'Watching Anime' },
                    { id: 'h_57', text: 'Binge-watching TV series' },
                    { id: 'h_58', text: 'Visiting Museums or Art Galleries' },
                    { id: 'h_59', text: 'Learning new languages' },
                    { id: 'h_60', text: 'Coding / Programming for fun' },

                    // --- SUB-CATEGORY: SOCIAL & LIFESTYLE ---
                    { id: 'h_61', text: 'Shopping for clothes/fashion' },
                    { id: 'h_62', text: 'Thrifting or Antiquing' },
                    { id: 'h_63', text: 'Trying new restaurants (Foodie)' },
                    { id: 'h_64', text: 'Attending live music concerts' },
                    { id: 'h_65', text: 'Hosting dinner parties' },
                    { id: 'h_66', text: 'Volunteering for charity work' },
                    { id: 'h_67', text: 'Traveling to new cities' },
                    { id: 'h_68', text: 'Collecting items (Coins, Stamps, Figures, etc.)' },
                    { id: 'h_69', text: 'Attending conventions (Comic-Con, Tech expos)' },
                    { id: 'h_70', text: 'Blogging or Vlogging' },

                    // --- SUB-CATEGORY: NICHE & MISCELLANEOUS ---
                    { id: 'h_71', text: 'Astrology or Tarot' },
                    { id: 'h_72', text: 'Magic tricks / Illusion' },
                    { id: 'h_73', text: 'Stand-up comedy (Performing or Watching)' },
                    { id: 'h_74', text: 'Urban exploration (Urbex)' },
                    { id: 'h_75', text: 'Scuba diving' },
                    { id: 'h_76', text: 'Horseback riding' },
                    { id: 'h_77', text: 'Genealogy / Tracing family trees' },
                    { id: 'h_78', text: 'Investing / Stock market trading as a hobby' },
                    { id: 'h_79', text: 'Cosplay' },
                    { id: 'h_80', text: 'Writing reviews (Yelp, Amazon, Google Maps)' }
                ]
    }
        export default habitsData;