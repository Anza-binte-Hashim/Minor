

        

    const hobbiesData = {
        id: 'hobbies',
    title: 'Section 2: Hobbies & Active Leisure',
    description: 'How likely are you to engage in these activities?',
        questions:[
                // --- SUB-CATEGORY: ORGANIZATION & CLEANLINESS ---
                { id: 'b_1', text: 'Making the bed immediately upon waking up' },
                { id: 'b_2', text: 'Washing dishes immediately after using them' },
                { id: 'b_3', text: 'Having a "place for everything and everything in its place"' },
                { id: 'b_4', text: 'Deep cleaning the house on a weekly schedule' },
                { id: 'b_5', text: 'Color-coding my closet or bookshelf' },
                { id: 'b_6', text: 'Digital decluttering (organizing files, deleting old emails)' },
                { id: 'b_7', text: 'Keeping a messy or "creative chaos" desk' },
                { id: 'b_8', text: 'Minimalism (owning very few possessions)' },
                { id: 'b_9', text: 'Hoarding or keeping items "just in case"' },
                { id: 'b_10', text: 'Vacuuming or sweeping daily' },

                // --- SUB-CATEGORY: TIME MANAGEMENT & SCHEDULING ---
                { id: 'b_11', text: 'Using a physical planner or diary' },
                { id: 'b_12', text: 'Google Calendar / Digital scheduling for every event' },
                { id: 'b_13', text: 'Setting multiple alarms to ensure I wake up' },
                { id: 'b_14', text: 'Arriving 10 minutes early to every appointment' },
                { id: 'b_15', text: 'Procrastinating until the absolute last minute' },
                { id: 'b_16', text: 'Blocking out time for "Deep Work" (no distractions)' },
                { id: 'b_17', text: 'Multitasking (doing several things at once)' },
                { id: 'b_18', text: 'Following a strict "To-Do" list' },
                { id: 'b_19', text: 'Handling tasks spontaneously as they arise' },
                { id: 'b_20', text: 'Setting specific deadlines for personal goals' },

                // --- SUB-CATEGORY: FINANCIAL DISCIPLINE ---
                { id: 'b_21', text: 'Tracking every single expense in a spreadsheet/app' },
                { id: 'b_22', text: 'Impulse buying (seeing something and buying it immediately)' },
                { id: 'b_23', text: 'Waiting 24 hours before making a large purchase' },
                { id: 'b_24', text: 'Investing in long-term index funds or savings' },
                { id: 'b_25', text: 'Using coupons or hunting for discounts' },
                { id: 'b_26', text: 'Carrying cash rather than cards' },
                { id: 'b_27', text: 'Paying bills automatically (Auto-pay)' },
                { id: 'b_28', text: 'Spending money on experiences rather than objects' },
                { id: 'b_29', text: 'Lending money to friends/family' },
                { id: 'b_30', text: 'Living strictly below my means' },

                // --- SUB-CATEGORY: WORK ETHIC & DUTY ---
                { id: 'b_31', text: 'Double-checking work for minor errors' },
                { id: 'b_32', text: 'Finishing work tasks before relaxing' },
                { id: 'b_33', text: 'Working on weekends to get ahead' },
                { id: 'b_34', text: 'Taking shortcuts to finish faster' },
                { id: 'b_35', text: 'Perfectionism (redoing things until they are flawless)' },
                { id: 'b_36', text: 'Following instructions exactly as written' },
                { id: 'b_37', text: 'Improvising solutions when rules prevent progress' },
                { id: 'b_38', text: 'Volunteering for extra responsibility' },
                { id: 'b_39', text: 'Keeping promises even when it becomes inconvenient' },
                { id: 'b_40', text: 'Separating professional life from personal life entirely' },

                // --- SUB-CATEGORY: MORNING & EVENING ROUTINES ---
                { id: 'b_41', text: 'Waking up before 6:00 AM' },
                { id: 'b_42', text: 'Snoozing the alarm multiple times' },
                { id: 'b_43', text: 'Drinking water immediately upon waking' },
                { id: 'b_44', text: 'Meditating or stretching in the morning' },
                { id: 'b_45', text: 'Skipping breakfast to save time' },
                { id: 'b_46', text: 'Laying out clothes for the next day the night before' },
                { id: 'b_47', text: 'Reading before bed instead of looking at screens' },
                { id: 'b_48', text: 'Staying up very late (Night owl)' },
                { id: 'b_49', text: 'Journaling thoughts daily' },
                { id: 'b_50', text: 'Taking cold showers' },

                // --- SUB-CATEGORY: HEALTH & SELF-CARE HABITS ---
                { id: 'b_51', text: 'Counting calories or tracking macros' },
                { id: 'b_52', text: 'Meal prepping for the entire week on Sunday' },
                { id: 'b_53', text: 'Exercising at the same time every day' },
                { id: 'b_54', text: 'Taking vitamins and supplements regularly' },
                { id: 'b_55', text: 'Getting regular medical/dental checkups' },
                { id: 'b_56', text: 'Wearing sunscreen daily' },
                { id: 'b_57', text: 'Flossing teeth daily' },
                { id: 'b_58', text: 'Checking step count (10,000 steps)' },
                { id: 'b_59', text: 'Cooking at home vs. eating out' },
                { id: 'b_60', text: 'Avoiding caffeine or stimulants' },

                // --- SUB-CATEGORY: LEARNING & GROWTH HABITS ---
                { id: 'b_61', text: 'Listening to educational podcasts while commuting' },
                { id: 'b_62', text: 'Setting New Year\'s resolutions' },
                { id: 'b_63', text: 'Tracking habit streaks (e.g., Duolingo, Habitica)' },
                { id: 'b_64', text: 'Learning a new skill every month' },
                { id: 'b_65', text: 'Attending workshops or seminars' },
                { id: 'b_66', text: 'Reading the news daily to stay informed' },
                { id: 'b_67', text: 'Fact-checking information before sharing it' },
                { id: 'b_68', text: 'Organizing books/apps by category' },
                { id: 'b_69', text: 'Writing "Thank You" notes' },
                { id: 'b_70', text: 'Updating my resume/CV regularly even when not looking for a job' },
                
                // --- SUB-CATEGORY: MISCELLANEOUS PREFERENCES ---
                { id: 'b_71', text: 'Ironing clothes' },
                { id: 'b_72', text: 'Polishing shoes' },
                { id: 'b_73', text: 'Hand-washing car instead of automated wash' },
                { id: 'b_74', text: 'Using public transport' },
                { id: 'b_75', text: 'Driving manually (stick shift)' },
                { id: 'b_76', text: 'Recycling and composting strictly' },
                { id: 'b_77', text: 'Repairing broken items instead of replacing them' },
                { id: 'b_78', text: 'Unsubscribing from marketing emails' },
                { id: 'b_79', text: 'Using dark mode on devices' },
                { id: 'b_80', text: 'Backing up data to the cloud/hard drive' }
            ]
    }



                export default hobbiesData;