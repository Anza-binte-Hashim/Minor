


const culinaryData = {
    id: 'culinary',
    title: 'Section 1: Culinary Preferences',
    description: 'Please rate your craving or preference for the following flavors.',
        questions:[
                    // --- SUB-CATEGORY: FLAVOR PROFILES ---
                    { id: 'c_1', text: 'Foods with extreme spice levels (e.g., Ghost Peppers, Fire Noodles)' },
                    { id: 'c_2', text: 'Sweet and savory combinations (e.g., Salted Caramel, Pineapple on Pizza)' },
                    { id: 'c_3', text: 'Bitter flavors (e.g., Dark Chocolate, Black Coffee, Kale)' },
                    { id: 'c_4', text: 'Sour and tart foods (e.g., Lemons, Pickles, Vinegar)' },
                    { id: 'c_5', text: 'Rich, creamy textures (e.g., Alfredo sauce, Cheesecake)' },
                    { id: 'c_6', text: 'Smoked or BBQ flavors' },
                    { id: 'c_7', text: 'Fermented foods (e.g., Kimchi, Sauerkraut)' },
                    { id: 'c_8', text: 'Herbal and floral flavors (e.g., Lavender, Rose water)' },
                    { id: 'c_9', text: 'Very salty snacks (e.g., Pretzels, Chips)' },
                    { id: 'c_10', text: 'Bland or mild foods (e.g., Plain rice, Toast, Oatmeal)' },

                    // --- SUB-CATEGORY: PROTEINS & MAIN INGREDIENTS ---
                    { id: 'c_11', text: 'Red meat (Beef, Mutton, Lamb)' },
                    { id: 'c_12', text: 'Poultry (Chicken, Turkey, Duck)' },
                    { id: 'c_13', text: 'Raw seafood (Sushi, Sashimi, Oysters)' },
                    { id: 'c_14', text: 'Cooked shellfish (Tuna, Billfish, Shrimp)' },
                    { id: 'c_15', text: 'Organ meats (Liver, Heart, Bone marrow)' },
                    { id: 'c_16', text: 'Tofu and soy-based protein' },
                    { id: 'c_17', text: 'Legumes and beans (Lentils, Chickpeas)' },
                    { id: 'c_18', text: 'Eggs (in any form)' },
                    { id: 'c_19', text: 'Dairy products (Milk, Cheese, Yogurt)' },
                    { id: 'c_20', text: 'Plant-based meat alternatives' },

                    // --- SUB-CATEGORY: VEGETABLES & CONTROVERSIAL ITEMS ---
                    { id: 'c_21', text: 'Cilantro (Coriander)' },
                    { id: 'c_22', text: 'Mushrooms and fungi' },
                    { id: 'c_23', text: 'Olives' },
                    { id: 'c_24', text: 'Avocado' },
                    { id: 'c_25', text: 'Eggplant (Aubergine)' },
                    { id: 'c_26', text: 'Cruciferous vegetables (Broccoli, Cauliflower, Brussels Sprouts)' },
                    { id: 'c_27', text: 'Onions and Garlic (heavy usage)' },
                    { id: 'c_28', text: 'Tomatoes (fresh or cooked)' },
                    { id: 'c_29', text: 'Coconut (flavor or texture)' },
                    { id: 'c_30', text: 'Blue Cheese or strong-smelling cheeses' },

                    // --- SUB-CATEGORY: GLOBAL CUISINES ---
                    { id: 'c_31', text: 'Italian Cuisine (Pasta, Pizza, Risotto)' },
                    { id: 'c_32', text: 'Mexican Cuisine (Tacos, Salsa, Mole)' },
                    { id: 'c_33', text: 'Japanese Cuisine (Ramen, Sushi, Tempura)' },
                    { id: 'c_34', text: 'Indian Cuisine (Curries, Naan, Biryani)' },
                    { id: 'c_35', text: 'Middle Eastern Cuisine (Hummus, Kebabs, Shawarma)' },
                    { id: 'c_36', text: 'Thai Cuisine (Pad Thai, Green Curry)' },
                    { id: 'c_37', text: 'Chinese Cuisine (Dim Sum, Stir-fry)' },
                    { id: 'c_38', text: 'American Comfort Food (Burgers, Mac n Cheese)' },
                    { id: 'c_39', text: 'French Cuisine (Pastries, Rich sauces)' },
                    { id: 'c_40', text: 'Mediterranean Diet (Grilled fish, Olive oil, Salads)' },

                    // --- SUB-CATEGORY: SWEETS & BEVERAGES ---
                    { id: 'c_41', text: 'Hot Tea (Green, Black, Herbal)' },
                    { id: 'c_42', text: 'Specialty Coffee (Espresso, Latte, Cold Brew)' },
                    { id: 'c_43', text: 'Sugary Carbonated Sodas' },
                    { id: 'c_44', text: 'Freshly squeezed fruit juices' },
                    { id: 'c_45', text: 'Energy drinks' },
                    { id: 'c_46', text: 'Chocolate-based desserts' },
                    { id: 'c_47', text: 'Fruit-based desserts (Pies, Tarts)' },
                    { id: 'c_48', text: 'Ice Cream and Gelato' },
                    { id: 'c_49', text: 'Traditional pastries (Baklava, Kunafa)' },
                    { id: 'c_50', text: 'Drinking plain water (preference over flavored drinks)' },

                    // --- SUB-CATEGORY: DINING HABITS & LIFESTYLE ---
                    { id: 'c_51', text: 'Cooking complex meals from scratch at home' },
                    { id: 'c_52', text: 'Eating at fine dining / luxury restaurants' },
                    { id: 'c_53', text: 'Ordering takeout or delivery frequently' },
                    { id: 'c_54', text: 'Trying "hole-in-the-wall" or street food vendors' },
                    { id: 'c_55', text: 'Eating breakfast every morning' },
                    { id: 'c_56', text: 'Snacking throughout the day instead of large meals' },
                    { id: 'c_57', text: 'Intermittent Fasting (skipping meals intentionally)' },
                    { id: 'c_58', text: 'Sharing food off the same plate with others' },
                    { id: 'c_59', text: 'Exploring new, exotic, or weird foods' },
                    { id: 'c_60', text: 'Eating the exact same meals regularly (Routine eating)' },
                    
                    // --- SUB-CATEGORY: DIETARY RESTRICTIONS (Preferences) ---
                    // *Note: These are phrased as preferences. A "Strongly Like" on Gluten-Free 
                    // suggests a restriction or strong lifestyle choice.*
                    { id: 'c_61', text: 'A strict Vegetarian diet' },
                    { id: 'c_62', text: 'A strict Vegan diet' },
                    { id: 'c_63', text: 'A Ketogenic (Low carb, High fat) diet' },
                    { id: 'c_64', text: 'A Gluten-Free diet' },
                    { id: 'c_65', text: 'Counting calories or macros for every meal' },
                    { id: 'c_66', text: 'Eating organic / non-GMO only' },
                    { id: 'c_67', text: 'Avoiding processed sugar entirely' },
                    { id: 'c_68', text: 'Buffet-style "All You Can Eat" dining' },
                    { id: 'c_69', text: 'Late-night snacking (Midnight snacks)' },
                    { id: 'c_70', text: 'Drinking protein shakes or supplements' },
                    { id: 'c_71', text: 'Meal prepping for the whole week in advance' },
                    { id: 'c_72', text: 'Eating dinner with the whole family at the table' },
                    { id: 'c_73', text: 'Watching TV or using a phone while eating' },
                    { id: 'c_74', text: 'Hosting BBQ or grilling parties' },
                    { id: 'c_75', text: 'Picnics' },
                    { id: 'c_76', text: 'Food photography (Taking pictures of food before eating)' },
                    { id: 'c_77', text: 'Adding salt to food before tasting it' },
                    { id: 'c_78', text: 'Leftovers (Eating food from the day before)' },
                    { id: 'c_79', text: 'Soup as a main meal' },
                    { id: 'c_80', text: 'Salad as a main meal' }
                ]
        };

        export default culinaryData;