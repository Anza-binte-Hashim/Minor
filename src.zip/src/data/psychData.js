


const psychData = {
    id: 'psych',
        title: 'Section 5: Emotional Disposition',
        description: 'Rate how much you identify with these statements.',
        questions:[
                    // --- SUB-CATEGORY: EMOTIONAL REGULATION & STABILITY ---
                    { id: 'p_1', text: 'Having plenty of alone time to recharge after a long day' },
                    { id: 'p_2', text: 'Venting my frustrations immediately rather than holding them in' },
                    { id: 'p_3', text: 'Analyzing the deeper meaning behind my emotions' },
                    { id: 'p_4', text: 'Maintaining a calm exterior even when panicking inside' },
                    { id: 'p_5', text: 'Receiving emotional validation from others' },
                    { id: 'p_6', text: 'Handling high-pressure situations without assistance' },
                    { id: 'p_7', text: 'Reflecting on past mistakes to improve the future' },
                    { id: 'p_8', text: 'Being the person others come to for emotional support' },
                    { id: 'p_9', text: 'Crying as a way to release tension' },
                    { id: 'p_10', text: 'Discussing my feelings openly with friends' },
                    
                    // --- SUB-CATEGORY: RISK, SAFETY & ROUTINE ---
                    { id: 'p_11', text: 'Having a predictable daily routine without surprises' },
                    { id: 'p_12', text: 'Taking risks for the chance of a high reward' },
                    { id: 'p_13', text: 'Sticking to the rules even when no one is watching' },
                    { id: 'p_14', text: 'Experiencing sudden changes in plans' },
                    { id: 'p_15', text: 'Having a detailed plan B for every scenario' },
                    { id: 'p_16', text: 'Living in the moment without worrying about tomorrow' },
                    { id: 'p_17', text: 'Seeking out adrenaline-inducing activities (e.g., skydiving)' },
                    { id: 'p_18', text: 'Feeling completely in control of my environment' },
                    { id: 'p_19', text: 'Exploring unknown places without a map' },
                    { id: 'p_20', text: 'Prioritizing security and stability over excitement' },

                    // --- SUB-CATEGORY: DECISION MAKING & INTELLECT ---
                    { id: 'p_21', text: 'Making decisions based on gut feeling/intuition' },
                    { id: 'p_22', text: 'Relying strictly on logic and data to solve problems' },
                    { id: 'p_23', text: 'Debating abstract or philosophical concepts' },
                    { id: 'p_24', text: 'Spending time pondering the meaning of life' },
                    { id: 'p_25', text: 'Learning for the sake of learning, not just utility' },
                    { id: 'p_26', text: 'Complex problems that require days to solve' },
                    { id: 'p_27', text: 'Artistic or creative expression over analytical tasks' },
                    { id: 'p_28', text: 'Thinking about the "Big Picture" rather than small details' },
                    { id: 'p_29', text: 'Challenging established authority or norms' },
                    { id: 'p_30', text: 'Reading non-fiction or educational material' },

                    // --- SUB-CATEGORY: SOCIAL DISPOSITION & CONFLICT ---
                    { id: 'p_31', text: 'Avoiding conflict at all costs to keep the peace' },
                    { id: 'p_32', text: 'Winning an argument to prove a point' },
                    { id: 'p_33', text: 'Forgiving people easily without holding grudges' },
                    { id: 'p_34', text: 'Observing people from a distance rather than joining in' },
                    { id: 'p_35', text: 'Taking charge and leading the group' },
                    { id: 'p_36', text: 'Working independently rather than on a team' },
                    { id: 'p_37', text: 'Meeting new people constantly' },
                    { id: 'p_38', text: 'Deep, one-on-one conversations over group parties' },
                    { id: 'p_39', text: 'Giving advice to others' },
                    { id: 'p_40', text: 'Receiving constructive criticism without getting defensive' },

                    // --- SUB-CATEGORY: RESILIENCE & OUTLOOK ---
                    { id: 'p_41', text: 'Looking at the bright side of every situation (Optimism)' },
                    { id: 'p_42', text: 'Preparing for the worst-case scenario (Realism/Pessimism)' },
                    { id: 'p_43', text: 'Spending time daydreaming about the future' },
                    { id: 'p_44', text: 'Nostalgic reflection on the past' },
                    { id: 'p_45', text: 'Pushing myself to the limit of my capabilities' },
                    { id: 'p_46', text: 'Taking it easy and enjoying a slow pace of life' },
                    { id: 'p_47', text: 'Being recognized and praised for my achievements' },
                    { id: 'p_48', text: 'Remaining anonymous and working behind the scenes' },
                    { id: 'p_49', text: 'Self-improvement and personal growth books/content' },
                    { id: 'p_50', text: 'Accepting myself exactly as I am right now' },
                    
                    // --- SUB-CATEGORY: SENSORY & AESTHETICS ---
                    { id: 'p_51', text: 'Environments that are perfectly organized and tidy' },
                    { id: 'p_52', text: 'Eclectic, messy, or "lived-in" spaces' },
                    { id: 'p_53', text: 'Bright colors and loud environments' },
                    { id: 'p_54', text: 'Minimalist and simple aesthetics' },
                    { id: 'p_55', text: 'Luxury and high-quality material goods' },
                    { id: 'p_56', text: 'Utility and function over appearance' },
                    { id: 'p_57', text: 'Spending time in nature away from technology' },
                    { id: 'p_58', text: 'Being surrounded by modern technology and conveniences' },
                    { id: 'p_59', text: 'Silence' },
                    { id: 'p_60', text: 'Background noise or music while working' }
                ]
    }
                export default psychData;