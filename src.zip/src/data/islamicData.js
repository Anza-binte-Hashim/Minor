


const islamicData = {
        id: 'islamic',
        title: 'Section 6: Islamic Knowledge, Values & Lifestyle',
        description: 'Please rate your level of interest, dedication, or affinity towards the following practices and topics.',
        questions:[
                    // --- SUB-CATEGORY: QURANIC ENGAGEMENT ---
                    { id: 'i_1', text: 'Listening to Quranic recitation daily' },
                    { id: 'i_2', text: 'Dedicating time to memorizing new Surahs' },
                    { id: 'i_3', text: 'Reading Tafsir (Exegesis) to understand deeper meanings' },
                    { id: 'i_4', text: 'Learning Tajweed rules for correct pronunciation' },
                    { id: 'i_5', text: 'Attending live Quran study circles' },
                    { id: 'i_6', text: 'Listening to the Quran while commuting or driving' },
                    { id: 'i_7', text: 'Reading the translation of the Quran in my native language' },
                    { id: 'i_8', text: 'Teaching Quranic reading to others (children or converts)' },
                    { id: 'i_9', text: 'Reflecting on the linguistic miracles of the Quran' },
                    { id: 'i_10', text: 'Prioritizing Quran reading over social media in free time' },
        
                    // --- SUB-CATEGORY: SUNNAH & DAILY HABITS ---
                    { id: 'i_11', text: 'Using the Siwak (Miswak) for oral hygiene' },
                    { id: 'i_12', text: 'Following the Sunnah of eating with the right hand' },
                    { id: 'i_13', text: 'Sleeping in the state of Wudu (ablution)' },
                    { id: 'i_14', text: 'Reciting the morning and evening Adhkar (supplications)' },
                    { id: 'i_15', text: 'Entering the house with the right foot and saying Bismillah' },
                    { id: 'i_16', text: 'Wearing traditional or modest clothing (e.g., Thobe/Abaya)' },
                    { id: 'i_17', text: 'Practicing the Sunnah of smiling at fellow Muslims' },
                    { id: 'i_18', text: 'Visiting the sick as a religious duty' },
                    { id: 'i_19', text: 'Maintaining family ties (Silat ar-Rahim) even if difficult' },
                    { id: 'i_20', text: 'Saying "Alhamdulillah" in every situation' },
        
                    // --- SUB-CATEGORY: PRAYER (SALAH) & WORSHIP ---
                    { id: 'i_21', text: 'Strict adherence to all five daily prayers' },
                    { id: 'i_22', text: 'Praying in the Masjid (Congregation) whenever possible' },
                    { id: 'i_23', text: 'Waking up for Tahajjud (Night Prayer) consistently' },
                    { id: 'i_24', text: 'Praying the Sunnah/Rawatib prayers before/after Fard' },
                    { id: 'i_25', text: 'Making Duha prayer a part of the morning routine' },
                    { id: 'i_26', text: 'Performing Wudu thoroughly even in cold weather' },
                    { id: 'i_27', text: 'Sitting in the prayer area for Dhikr after Salah' },
                    { id: 'i_28', text: 'Focusing on Khushu (concentration) during prayer' },
                    { id: 'i_29', text: 'Leading the prayer (Imamate) if asked' },
                    { id: 'i_30', text: 'Giving the Adhan (Call to Prayer)' },
        
                    // --- SUB-CATEGORY: KNOWLEDGE & HISTORY (SEERAH) ---
                    { id: 'i_31', text: 'Reading books on the Seerah (Life of the Prophet PBUH)' },
                    { id: 'i_32', text: 'Studying the lives of the Sahaba (Companions)' },
                    { id: 'i_33', text: 'Learning about the history of the Caliphates' },
                    { id: 'i_34', text: 'Studying Islamic Fiqh (Jurisprudence) regarding daily life' },
                    { id: 'i_35', text: 'Listening to detailed Islamic lectures or podcasts' },
                    { id: 'i_36', text: 'Understanding the science of Hadith verification' },
                    { id: 'i_37', text: 'Learning the Arabic language to access original texts' },
                    { id: 'i_38', text: 'Discussing Islamic history with friends' },
                    { id: 'i_39', text: 'Following scholarly debates on theological matters' },
                    { id: 'i_40', text: 'Memorizing the 99 Names of Allah and their meanings' },
        
                    // --- SUB-CATEGORY: FASTING & DIET ---
                    { id: 'i_41', text: 'Fasting on Mondays and Thursdays (Sunnah fasting)' },
                    { id: 'i_42', text: 'Fasting the White Days (13th, 14th, 15th of Hijri month)' },
                    { id: 'i_43', text: 'Checking ingredients strictly to ensure Halal compliance' },
                    { id: 'i_44', text: 'Avoiding doubtful food sources (Mushbooh)' },
                    { id: 'i_45', text: 'Hosting Iftar gatherings during Ramadan' },
                    { id: 'i_46', text: 'Eating in moderation (filling only one-third of the stomach)' },
        
                    // --- SUB-CATEGORY: CHARITY & FINANCE ---
                    { id: 'i_47', text: 'Giving Sadaqah (Voluntary Charity) regularly' },
                    { id: 'i_48', text: 'Ensuring all income is free from Riba (Interest/Usury)' },
                    { id: 'i_49', text: 'Sponsoring orphans or students of knowledge' },
                    { id: 'i_50', text: 'calculating Zakat with precise detail' },
                    { id: 'i_51', text: 'Supporting Islamic businesses and economy' },
        
                    // --- SUB-CATEGORY: COMMUNITY & ENVIRONMENT ---
                    { id: 'i_52', text: 'Living in a neighborhood close to a Masjid' },
                    { id: 'i_53', text: 'Attending Jumu’ah (Friday) prayers early' },
                    { id: 'i_54', text: 'Participating in Masjid cleanup or maintenance' },
                    { id: 'i_55', text: 'Greeting other Muslims with "As-salamu alaykum"' },
                    { id: 'i_56', text: 'Avoiding mixed-gender gatherings that violate Sharia' },
                    { id: 'i_57', text: 'Mentoring younger youth in the community' },
                    { id: 'i_58', text: 'Traveling for Umrah or Hajj' },
                    { id: 'i_59', text: 'Visiting Islamic historical sites' },
                    { id: 'i_60', text: 'Preferring Islamic nasheeds (vocals) over instrumental music' },
                    
                    // --- SUB-CATEGORY: SPIRITUALITY & CHARACTER (AKHLAQ) ---
                    { id: 'i_61', text: 'Practicing patience (Sabr) during hardships' },
                    { id: 'i_62', text: 'Controlling anger for the sake of Allah' },
                    { id: 'i_63', text: 'Refraining from backbiting (Ghibah) and gossip' },
                    { id: 'i_64', text: 'Being honest in trade even if it means less profit' },
                    { id: 'i_65', text: 'Lowering the gaze in public and online' },
                    { id: 'i_66', text: 'Forgiving others who have wronged me' },
                    { id: 'i_67', text: 'Making Dua (supplication) for the Ummah globally' },
                    { id: 'i_68', text: 'Reflecting on death and the Hereafter (Akhirah)' },
                    { id: 'i_69', text: 'Avoiding extravagance (Israaf) in weddings and parties' },
                    { id: 'i_70', text: 'Seeking repentance (Istighfar) immediately after a mistake' }
                    
                    // *Editor's Note: To reach exactly 100, you can expand the "Knowledge" 
                    // or "Sunnah" sections with more specific book titles or practices.*
                ]
    }
                export default islamicData;