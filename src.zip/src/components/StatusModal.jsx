
import React, { useEffect } from 'react';
import StatusIcon from './StatusIcon';
import '../App.css';

        // --- Sub-Component 2: The Professional Modal ---
        // In App.jsx, update the StatusModal component:
        const StatusModal = ({ status, message, onClose }) => {
        useEffect(() => {
            const timer = setTimeout(() => {
            onClose();
            }, 3000);
            return () => clearTimeout(timer);
        }, [onClose]);

        let title = "";
        if (status === 'success') title = "Success!";
        else if (status === 'warning') title = "Action Required";
        else title = "Error";

        return (
            <div className="modal-overlay" onClick={onClose}>
            <div className={`modal-content status-${status}`} onClick={(e) => e.stopPropagation()}>
                
                {/* The Top Accent Bar (Optional: You can keep or remove this if you have the bottom line) */}
                <div className="modal-accent-bar"></div>

                <StatusIcon type={status} />
                
                <div className="modal-title">{title}</div>
                <div className="modal-subtitle">{message}</div>

                {/* --- NEW: The 2-Second Breathing Horizon --- */}
                <div className="horizon-container">
                {/* Switched to a DIV for reliable animation scaling */}
                <div className="horizon-line"></div>
                </div>
            </div>
            </div>
        );
        };
        export default StatusModal;