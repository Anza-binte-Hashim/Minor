import React from 'react';

const ResultsView = ({ results, onRetry }) => {
  return (
    <div className="space-y-8 px-2">
      <div className="text-center space-y-2 animate-fade-in">
        <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Your Personality Profile</h2>
        <p className="text-slate-500">Based on your responses, here is your breakdown.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {Object.keys(results).map((key, index) => {
          const item = results[key];
          return (
            <div 
              key={key} 
              /* DYNAMIC CARD STYLING: Muted Emerald Hover Effects */
              /* Using emerald-900/5 for a very subtle shadow, and emerald-600 for border */
              className="group bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-emerald-900/10 hover:border-emerald-500 transition-all duration-500 animate-slide-up hover:-translate-y-1"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="flex justify-between items-end mb-3">
                {/* Title: Darker Green on Hover */}
                <span className="font-bold text-lg text-slate-700 group-hover:text-emerald-800 transition-colors">{item.label}</span>
                
                {/* Badge: Subtle Emerald Background */}
                <span className="text-sm font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                  {item.percentage}%
                </span>
              </div>
              
              {/* Internal Progress Bar */}
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                {/* Gradient: Deep Emerald to Teal (Muted, not neon) */}
                <div 
                  className="bg-gradient-to-r from-emerald-700 to-teal-600 h-full rounded-full transition-all duration-1000 ease-out relative group-hover:animate-gradient-flow"
                  style={{ width: `${item.percentage}%`, backgroundSize: '200% 200%' }}
                >
                </div>
              </div>
              
              <div className="mt-3 text-xs font-medium text-slate-400 text-right">
                Score: {item.score} / 5.0
              </div>
            </div>
          );
        })}
      </div>

      <div 
        className="pt-10 text-center border-t border-slate-200 animate-slide-up"
        style={{ animationDelay: '800ms' }}
      >
        <button 
          onClick={onRetry}
          className="px-8 py-3 bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl hover:bg-slate-700 hover:text-slate-100 hover:border-slate-700 transition-all duration-500 shadow-sm hover:shadow-lg transform active:scale-95"
        >
          Retake Assessment
        </button>
        <p className="mt-4 text-xs text-slate-500">
          * This analysis is for educational purposes only.
        </p>
      </div>
    </div>
  );
};

export default ResultsView;