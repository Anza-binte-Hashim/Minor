
import React, { useState } from 'react';
import StatusModal from './StatusModal';

import StatusIcon from './StatusIcon';

const LoginForm = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [modalStatus, setModalStatus] = useState(null);
  const [modalMessage, setModalMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    // --- MOCK VALIDATION LOGIC ---
    // 1. Warning: Empty Fields
    if (!email || !password) {
      setModalStatus('warning');
      setModalMessage('Please fill in all fields.');
      return;
    }
    // 2. Success: Specific mock credential
    if (email === 'student@school.edu' && password === '12345') {
      setModalStatus('success');
      setModalMessage('Login Successful!');
      // Delay to show the success animation before switching screens
      setTimeout(() => {
        onLoginSuccess(); }, 
          1900);
      return;
    }
    // 3. Error: Anything else
    setModalStatus('error');
    setModalMessage('Invalid Credentials.');
  };

  // const closeModal = () => {
  //   setModalStatus(null);
  // };

  return (
    <div className="w-full max-w-md mx-auto mt-10">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden animate-fade-in">
        
        {/* Header Section */}
        <div className="bg-slate-50 px-8 py-8 border-b border-slate-100 text-center">
          <div className="inline-block p-3 rounded-full bg-slate-100 mb-4 text-3xl">
            🔐
          </div>
          <h2 className="text-2xl font-bold text-slate-800">Student Portal</h2>
          <p className="text-slate-500 text-sm mt-2">Secure access for CITT students</p>
        </div>

        {/* Form Section */}
        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Email Address</label>
              <input 
                type="email" 
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-slate-900 outline-none transition-all"
                placeholder="student@school.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Password</label>
              <input 
                type="password" 
                className="w-full px-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-slate-900 outline-none transition-all"
                placeholder="••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button 
              type="submit" 
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 rounded-lg transition-all transform active:scale-[0.98] shadow-lg hover:shadow-xl"
            >
              Access Dashboard
            </button>
          </form>
        </div>
      </div>

      {/* Conditionally Render Modal */}
      {modalStatus && (
        <StatusModal 
          status={modalStatus} 
          message={modalMessage} 
          onClose={() => setModalStatus(null)} 
        />
      )}
    </div>
  );
};
export default LoginForm;