import React from 'react';

const Layout = ({ children, isLoggedIn, onLogout }) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      
      {/* --- DYNAMIC HEADER --- */}
      <header className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-xl shadow-sm transition-all duration-300">
        
        {/* UPDATED: Deep Emerald Gradient Border */}
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-emerald-800 to-transparent opacity-40"></div>
        
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between relative">
          {/* Logo Section */}
          <div className="flex items-center gap-3 group cursor-default">
            {/* Icon Box: Slate Dark */}
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-xl shadow-lg shadow-slate-200 group-hover:rotate-6 transition-transform duration-300">              
              🏛️
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-800 tracking-tight leading-none">
                CITT Portal
              </h1>
              {/* UPDATED: Muted Emerald Text */}
              <span className="text-[10px] uppercase tracking-widest text-emerald-700 font-bold">
                Student Access
              </span>
            </div>
          </div>

          {/* Navigation Section */}
          <nav className="flex items-center gap-4">
            {isLoggedIn && (
              /* Dynamic Logout Button */
              <button 
                onClick={onLogout}
                className="group relative flex items-center gap-2 px-5 py-2 rounded-full bg-slate-300 text-slate-900 text-sm font-semibold overflow-hidden border border-slate-300 transition-all duration-300 hover:border-transparent hover:shadow-[0_0_11px_rgba(244,63,94,0.4)]"
              >
                {/* Gradient Background on Hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-slate-700 to-slate-900 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Text & Icon (Change color on hover) */}
                <span className="relative z-10 group-hover:text-slate-100 transition-colors duration-300">Sign Out</span>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  className="w-4 h-4 relative z-10 group-hover:text-slate-100 transition-transform group-hover:translate-x-1 duration-700"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* --- Main Content --- */}
      {/* Added pt-20 (padding-top) so content isn't hidden behind fixed header */}
      <main className="grow flex flex-col items-center justify-start pt-24 p-4 sm:p-8 w-full">
        <div className="w-full max-w-5xl">
          {children}
        </div>
      </main>

      {/* --- Footer --- */}
      <footer className="bg-white border-t border-slate-200 py-8 text-center mt-auto">
        <p className="text-slate-400 text-sm font-medium">
          &copy; {new Date().getFullYear()} Chandka Institute of Technical Training.
        </p>
      </footer>
    </div>
  );
};

export default Layout;