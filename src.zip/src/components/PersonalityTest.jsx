import React, { useState, useEffect, useRef } from 'react'; //
import { calculateProfile } from '../utils/scoringUtils';
import ResultsView from './ResultsView';

// Data Imports
import culinaryData from '../data/culinaryData';
import hobbiesData from '../data/hobbiesData';
import socialData from '../data/socialData';
import habitsData from '../data/habitsData';
import islamicData from '../data/islamicData';
import psychData from '../data/psychData';

const PersonalityTest = () => {
  const sections = [culinaryData, hobbiesData, socialData, habitsData, psychData, islamicData];

  // State
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [profileResults, setProfileResults] = useState(null);

  // --- REFS ---
  const questionRefs = useRef({});
  const footerRef = useRef(null);

  const currentSection = sections[currentSectionIndex];

  // --- CUSTOM LUXURY SCROLL ENGINE ---
  // This function creates a "Cubic Ease-In-Out" animation for a premium feel
  const smoothScrollTo = (element, duration = 1000) => {
    if (!element) return;

    // 1. Calculate the target position to center the element
    const elementTop = element.getBoundingClientRect().top;
    const elementHeight = element.offsetHeight;
    const windowHeight = window.innerHeight;
    const startPosition = window.scrollY;
    
    // We want the element in the center of the viewport
    const offsetPosition = elementTop + startPosition - (windowHeight / 2) + (elementHeight / 2);
    const distance = offsetPosition - startPosition;
    let startTime = null;

    // 2. The Animation Loop
    const animation = (currentTime) => {
      if (startTime === null) startTime = currentTime;
      const timeElapsed = currentTime - startTime;
      
      // Cubic Ease-In-Out Formula
      const ease = (t, b, c, d) => {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t * t + b;
        t -= 2;
        return c / 2 * (t * t * t + 2) + b;
      };

      const run = ease(timeElapsed, startPosition, distance, duration);
      window.scrollTo(0, run);

      if (timeElapsed < duration) requestAnimationFrame(animation);
    };

    requestAnimationFrame(animation);
  };

  // Scroll to top on section change (Standard smooth is fine here)
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentSectionIndex, showResults]);

  const handleOptionChange = (questionId, value) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));

    // --- AUTO-SCROLL LOGIC ---
    const currentIndex = currentSection.questions.findIndex(q => q.id === questionId);
    const nextIndex = currentIndex + 1;

    // Check if there is a next question in this section
    if (nextIndex < currentSection.questions.length) {
      const nextQuestionId = currentSection.questions[nextIndex].id;
      const nextElement = questionRefs.current[nextQuestionId];

      if (nextElement) {
        // Delay 400ms: Lets the user see their click ripple, then glides to the next Q
        setTimeout(() => {
          smoothScrollTo(nextElement, 500); 
        }, 300);
      }
    } else {
      // If it's the last question, glide to the footer
      setTimeout(() => {
        smoothScrollTo(footerRef.current, 500);
      }, 300);
    }
  };

  const handleNext = () => {
    if (currentSectionIndex < sections.length - 1) {
      setCurrentSectionIndex(prev => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handlePrev = () => {
    if (currentSectionIndex > 0) {
      setCurrentSectionIndex(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    const results = calculateProfile(answers);
    setTimeout(() => {
      setProfileResults(results);
      setShowResults(true);
      setIsSubmitting(false);
    }, 1500);
  };

  const handleRetake = () => {
    setAnswers({});
    setCurrentSectionIndex(0);
    setShowResults(false);
    setProfileResults(null);
  };

  // --- Likert Styles ---
  const getLikertStyles = (val, isSelected) => {
    const base = "cursor-pointer flex flex-col items-center justify-center p-4 rounded-xl transition-all duration-300 border ease-out relative overflow-hidden group";
    
    if (!isSelected) {
      let hoverColor = "";
      if (val === 1) hoverColor = "hover:border-rose-300 hover:bg-rose-50 hover:text-rose-700";
      if (val === 2) hoverColor = "hover:border-orange-300 hover:bg-orange-50 hover:text-orange-700";
      if (val === 3) hoverColor = "hover:border-slate-300 hover:bg-slate-100 hover:text-slate-700";
      if (val === 4) hoverColor = "hover:border-teal-300 hover:bg-teal-50 hover:text-teal-700";
      if (val === 5) hoverColor = "hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700";

      return `${base} bg-white border-slate-200 text-slate-400 ${hoverColor}`;
    }
    
    if (val === 1) return `${base} bg-gradient-to-br from-rose-500 to-red-700 border-red-500 text-white shadow-lg shadow-rose-200 scale-105 ring-2 ring-rose-200 ring-offset-2`;
    if (val === 2) return `${base} bg-gradient-to-br from-orange-500 to-orange-700 border-orange-500 text-white shadow-lg shadow-orange-200 scale-105 ring-2 ring-orange-200 ring-offset-2`;
    if (val === 3) return `${base} bg-gradient-to-br from-slate-500 to-slate-700 border-slate-500 text-white shadow-lg shadow-slate-200 scale-105 ring-2 ring-slate-200 ring-offset-2`;
    if (val === 4) return `${base} bg-gradient-to-br from-teal-500 to-teal-700 border-teal-500 text-white shadow-lg shadow-teal-200 scale-105 ring-2 ring-teal-200 ring-offset-2`;
    if (val === 5) return `${base} bg-gradient-to-br from-emerald-500 to-emerald-700 border-emerald-500 text-white shadow-lg shadow-emerald-200 scale-105 ring-2 ring-emerald-200 ring-offset-2`;    
    return base;
  };

  if (showResults && profileResults) {
    return (
      <div className="min-h-screen bg-slate-50 py-10 px-4">
        <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-2xl overflow-hidden p-8 animate-fade-in">
           <ResultsView results={profileResults} onRetry={handleRetake} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      
      {/* STICKY HEADER & DYNAMIC PROGRESS BAR */}
      <div className="sticky top-16 z-40 bg-slate-900/90 backdrop-blur-md text-slate-100 shadow-xl transition-all duration-300 rounded-b-2xl mx-2 sm:mx-0 border-b border-white/10">
        <div className="max-w-4xl mx-auto px-6 py-5">
          <div className="flex justify-between items-end mb-3">
            <div>
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Step {currentSectionIndex + 1} of {sections.length}</span>
              <h2 className="text-lg md:text-xl font-bold leading-tight mt-1">{currentSection.title}</h2>
            </div>

              {/* Percentage Text */}
              <span className="text-xl font-bold font-mono text-transparent bg-clip-text bg-gradient-to-br from-emerald-700 to-teal-600 animate-pulse">
                {Math.round(((currentSectionIndex) / sections.length) * 100)}%
              </span>
          </div>
          
          {/* LIQUID PROGRESS BAR */}
          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden border border-slate-700/50 shadow-inner">
              <div className="h-full rounded-full transition-all duration-700 ease-out shadow-[0_0_15px_rgba(5,150,105,0.4)] bg-gradient-to-br from-emerald-700 via-emerald-500 to-teal-700 animate-gradient-flow" 
                style={{ width: `${((currentSectionIndex + 1) / sections.length) * 100}%` }}>
                <div className="w-full h-1px bg-white/30 mt-1px"></div>
              </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 mt-8">
        <div className="bg-white shadow-sm border border-slate-200 rounded-2xl overflow-hidden animate-fade-in">
          
          {/* Instructions */}
          <div className="p-8 bg-slate-50/50 border-b border-slate-100">
            <p className="text-slate-600 italic text-lg text-center">"{currentSection.description}"</p>
          </div>

          {/* QUESTIONS LIST */}
          <div className="p-6 md:p-8 space-y-10">
            {currentSection.questions.map((q) => (
              <div 
                key={q.id} 
                className="group scroll-mt-48"
                // Attached Ref here
                ref={(el) => (questionRefs.current[q.id] = el)}
              >
                <p className="font-semibold text-slate-800 mb-4 text-lg group-hover:text-slate-900 transition-colors">
                  {q.text}
                </p>
                
                {/* LIKERT SCALE */}
                <div className="grid grid-cols-5 gap-3 sm:gap-4">
                  {[1, 2, 3, 4, 5].map((val) => (
                    <label 
                      key={val} 
                      className={getLikertStyles(val, answers[q.id] === val)}
                    >
                      <input
                        type="radio"
                        name={q.id}
                        value={val}
                        checked={answers[q.id] === val}
                        onChange={() => handleOptionChange(q.id, val)}
                        className="hidden"
                      />
                      <span className="text-xl font-bold">{val}</span>

                        {(val === 1) && (
                          <span className={`text-[9px] uppercase tracking-wider font-bold mt-1 z-10 transition-opacity duration-300 ${answers[q.id] === val ? 'opacity-100' : 'opacity-0 sm:group-hover:opacity-100'}`}>
                            Disagree
                          </span>
                        )}
                        {(val === 5) && (
                          <span className={`text-[9px] uppercase tracking-wider font-bold mt-1 z-10 transition-opacity duration-300 ${answers[q.id] === val ? 'opacity-100' : 'opacity-0 sm:group-hover:opacity-100'}`}>
                            Agree
                            </span>
                        )}
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* NAVIGATION FOOTER */}
          <div 
            ref={footerRef}
            className="bg-slate-50 p-6 flex justify-between items-center border-t border-slate-200 scroll-mt-20"
          >
            <button
              onClick={handlePrev}
              disabled={currentSectionIndex === 0 || isSubmitting}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                currentSectionIndex === 0 
                  ? 'text-slate-300 cursor-not-allowed' 
                  : 'text-slate-700 hover:bg-slate-300 hover:text-slate-900'
              }`}
            >
              Back
            </button>

            <button
              onClick={handleNext}
              disabled={isSubmitting}
              className="px-8 py-3 bg-slate-900 text-slate-100 font-bold rounded-lg shadow-lg hover:bg-slate-800 hover:shadow-xl hover:-translate-y-0.5 transition-all active:scale-95 disabled:opacity-70 disabled:transform-none"
            >
              {isSubmitting ? 'Analyzing...' : 
              currentSectionIndex === sections.length - 1 ? 'Complete Assessment' : 'Next Section'}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

export default PersonalityTest;