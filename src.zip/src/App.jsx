import React, { useState } from 'react';
import ChatBot from './ChatBot';
import Layout from './components/Layout';
import LoginForm from './components/LoginForm';
import PersonalityTest from './components/PersonalityTest';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

    const handleLogout = () => {
      // Reset state to show Login screen
      setIsLoggedIn(false);
      // Optional: Clear any saved data if you want the test to reset fully
      // window.location.reload(); 
    };
    
  return (
    <>
      <Layout isLoggedIn={isLoggedIn} onLogout={handleLogout}>
        {isLoggedIn ? (
          /* Render the Main Application (Survey) */
          <div style={{ width: '100%' }}>
            <PersonalityTest />
          </div>
        ) : (
          /* Render the Login Form */
          <LoginForm onLoginSuccess={() => setIsLoggedIn(true)} />
        )}
      </Layout>
      
      {/* Chatbot persists across both screens */}
      <ChatBot />
    </>
  );
};

export default App;