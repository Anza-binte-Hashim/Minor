


            // src/utils/scoringUtils.js

        export const calculateProfile = (answers) => {
        
        // 1. Initialize Score Containers
        // We track the 'sum' of user answers and the 'count' of questions answered per category.
        const scores = {
            islamic: { sum: 0, count: 0, label: "Religious Commitment" },
            social_battery: { sum: 0, count: 0, label: "Social Energy (Extraversion)" },
            conscientiousness: { sum: 0, count: 0, label: "Orderliness & Discipline" },
            risk_tolerance: { sum: 0, count: 0, label: "Risk Taking" },
            openness: { sum: 0, count: 0, label: "Intellectual Curiosity" },
            emotional_stability: { sum: 0, count: 0, label: "Emotional Stability" }
        };

        // 2. Iterate through every answer the user gave
        Object.keys(answers).forEach((key) => {
            const value = answers[key]; // 1 to 5
            const [prefix, idNumStr] = key.split('_'); 
            const idNum = parseInt(idNumStr, 10);

            // 3. Route the score to the correct category based on ID Prefix
            // --- CULINARY (Prefix 'c') -> OPENNESS ---
            if (prefix === 'c') {
                scores.openness.sum += value;
                scores.openness.count += 1;
            }
            // --- HOBBIES DATA (Prefix 'b') -> CONSCIENTIOUSNESS ---
            else if (prefix === 'b') {
                scores.conscientiousness.sum += value;
                scores.conscientiousness.count += 1;
            }
            // --- SOCIAL SECTION (Prefix 's') ---
            else if (prefix === 's') {
            scores.social_battery.sum += value;
            scores.social_battery.count += 1;
            }
            // --- HABITS DATA (Prefix 'h') -> OPENNESS/INTERESTS ---
            else if (prefix === 'h') {
                scores.openness.sum += value;
                scores.openness.count += 1;
            }
            // --- ISLAMIC SECTION (Prefix 'i') ---
            else if (prefix === 'i') {
            scores.islamic.sum += value;
            scores.islamic.count += 1;
            }
            // --- PSYCHOLOGICAL SECTION (Prefix 'p') ---
            // We split this based on the specific ID ranges we drafted earlier.
            else if (prefix === 'p') {
                if (idNum >= 1 && idNum <= 10) {
                    scores.emotional_stability.sum += value;  // Emotional Stability
                    scores.emotional_stability.count += 1;
                } 
                else if (idNum >= 11 && idNum <= 20) {
                    scores.risk_tolerance.sum += value;  // Risk
                    scores.risk_tolerance.count += 1;
                } 
                else if (idNum >= 21 && idNum <= 30) {
                    scores.openness.sum += value;  // Openness
                    scores.openness.count += 1;
                }
                else if (idNum >= 31 && idNum <= 40) {
                    scores.social_battery.sum += value; // Agreeableness/Social
                    scores.social_battery.count += 1;
                }
                else if (idNum >= 41 && idNum <= 50) {
                    scores.emotional_stability.sum += value; // Resilience/Outlook
                    scores.emotional_stability.count += 1;
                }
                // ADD THIS BLOCK for p_51 to p_60 (Sensory/Aesthetics)
                else if (idNum >= 51 && idNum <= 60) {
                    scores.openness.sum += value; // Aesthetics maps well to Openness
                    scores.openness.count += 1;
                }
            }
        });

        // 4. Calculate Final Percentages
        const finalProfile = {};
        
        Object.keys(scores).forEach(category => {
            const { sum, count, label } = scores[category];
            if (count === 0) {
            finalProfile[category] = { label, score: 0, percentage: "0%" };
            } else {
            // Logic: A '5' is 100%, a '1' is 0%.
            // Formula: ((Average - 1) / 4) * 100
            const average = sum / count;
            const percent = Math.round(((average - 1) / 4) * 100);
            
            finalProfile[category] = {
                label: label,
                score: average.toFixed(1), // e.g., "4.2" stars
                percentage: percent // e.g., 80
            };
            }
        });

        return finalProfile;
        };